<template>
  <form>
    <v-text-field
      v-model="name"
      :error-messages="nameErrors"
      :counter="10"
      :rules="[rules.required]"
      label="Name"
      required
      @input="$v.name.$touch()"
      @blur="$v.name.$touch()"
    ></v-text-field>
    <v-text-field v-model="city" label="City"></v-text-field>

    <v-btn class="mr-4" @click.prevent="submit"> submit </v-btn>
  </form>
</template>

<script>
import { validationMixin } from "vuelidate";
import { required, maxLength } from "vuelidate/lib/validators";
export default {
  mixins: [validationMixin],
  validations: {
    name: { required, maxLength: maxLength(10) },
  },
  data: () => ({
    name: "",
    city: "",
    rules: {
        required: (value) => !!value || "por kon lashi ",
      },
  }),
  computed: {
    nameErrors() {
      const errors = [];
      if (!this.$v.name.$dirty) return errors;
      !this.$v.name.maxLength &&
        errors.push("Name must be at most 10 characters long");
      !this.$v.name.required && errors.push("Name is required.");
      return errors;
    },
  },
  methods: {
    submit() {
      let query = "";
        if (this.name) {
          query += "name=" + this.name;
        }
        if (this.city) {
          query += "&city=" + this.city;
        }
        this.$router.push("/weather?" + query);
      }
  },
};
</script>
